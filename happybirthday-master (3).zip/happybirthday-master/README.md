# 祝你生日快乐

> 代码来自网络, 本人稍作修改

食用 ：

index.html修改主要信息  **|**  time.js修改生日  **|**  index.js修改「想说的话」

demo : https://lincest.github.io/happybirthday/

![](https://youpai.roccoshi.top/img/20200801205158.png)

> 注意 : 字数过多 ( >3 ) 移动端易失真, 本人研究一番无果后放弃

